MEU CELULAR — PROTÓTIPO FUNCIONAL
====================================

Arquivos:
- index.html — loja completa em uma única página
- logo.png — logo extraído da imagem enviada

Funcionalidades:
- catálogo responsivo
- busca
- filtros por marca e preço
- ordenação
- carrinho persistido no navegador
- checkout com dados de cliente
- finalização por WhatsApp no número (11) 98955-7795
- layout preto e amarelo inspirado no catálogo aprovado

IMPORTANTE:
- Os preços/modelos deste protótipo são dados de demonstração e devem ser conferidos antes de publicar.
- O checkout ainda não processa cartão/Pix automaticamente; ele encaminha o pedido ao WhatsApp.
- Para uma loja comercial, o próximo passo é integrar gateway de pagamento, frete, estoque, domínio e painel administrativo.
